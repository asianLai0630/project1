#!/usr/bin/env python
# -*- coding: utf-8 -*-
# coding=<utf-8>

import os
import win32api
import win32con
import win32gui_struct
import win32gui

import Tkinter as Tk
from Tkinter import StringVar, IntVar
import ttk
import tkMessageBox as messagebox
import sys
import scapy
from binascii import hexlify

from scapy_ssl_tls.ssl_tls import *
from scapy.all import *

b=-1
c=0
ssid=[]
check = False
a=subprocess.check_output("netsh wlan show interfaces")

for line in a.split():
	ssid.append(line)
	b=b+1
	if line.startswith("SSID"):
		c=b+2
		check = True
if check:
    wifi=ssid[c]
else :
    print "4"
    wifi="請連wifi"

wifistatus=True

Main = None

class SysTrayIcon(object):
    QUIT = 'QUIT'
    SPECIAL_ACTIONS = [QUIT]
    FIRST_ID = 1314
    def __init__(s,
                 icon,
                 hover_text,
                 menu_options,
                 on_quit=None,
                 default_menu_index=None,
                 window_class_name=None,):
        s.icon = icon
        s.hover_text = hover_text
        s.on_quit = on_quit

        menu_options = menu_options + (("exit", None, s.QUIT),)
        s._next_action_id = s.FIRST_ID
        s.menu_actions_by_id = set()
        s.menu_options = s._add_ids_to_menu_options(list(menu_options))
        s.menu_actions_by_id = dict(s.menu_actions_by_id)
        del s._next_action_id

        s.default_menu_index = (default_menu_index or 0)
        s.window_class_name = window_class_name or "SysTrayIconPy"

        message_map = {win32gui.RegisterWindowMessage("TaskbarCreated"): s.refresh_icon,
                       win32con.WM_DESTROY: s.destroy,
                       win32con.WM_COMMAND: s.command,
                       win32con.WM_USER+20 : s.notify,}

        window_class = win32gui.WNDCLASS()
        window_class.hInstance = win32gui.GetModuleHandle(None)
        window_class.lpszClassName = s.window_class_name
        window_class.style = win32con.CS_VREDRAW | win32con.CS_HREDRAW;
        window_class.hCursor = win32gui.LoadCursor(0, win32con.IDC_ARROW)
        window_class.hbrBackground = win32con.COLOR_WINDOW
        window_class.lpfnWndProc = message_map 
        
        s.classAtom = win32gui.RegisterClass(window_class)

    def show_icon(s):
        hinst = win32gui.GetModuleHandle(None)
        style = win32con.WS_OVERLAPPED | win32con.WS_SYSMENU
        s.hwnd = win32gui.CreateWindow(s.classAtom,
                                          s.window_class_name,
                                          style,
                                          0,
                                          0,
                                          win32con.CW_USEDEFAULT,
                                          win32con.CW_USEDEFAULT,
                                          0,
                                          0,
                                          hinst,
                                          None)
        win32gui.UpdateWindow(s.hwnd)
        s.notify_id = None
        s.refresh_icon()
        
        win32gui.PumpMessages()

    def show_menu(s):
        menu = win32gui.CreatePopupMenu()
        s.create_menu(menu, s.menu_options)
        
        pos = win32gui.GetCursorPos()
        win32gui.SetForegroundWindow(s.hwnd)
        win32gui.TrackPopupMenu(menu,
                                win32con.TPM_LEFTALIGN,
                                pos[0],
                                pos[1],
                                0,
                                s.hwnd,
                                None)
        win32gui.PostMessage(s.hwnd, win32con.WM_NULL, 0, 0)

    def destroy(s, hwnd, msg, wparam, lparam):
        
        if s.on_quit: s.on_quit(s)
        nid = (s.hwnd, 0)
        win32gui.Shell_NotifyIcon(win32gui.NIM_DELETE, nid)
        win32gui.PostQuitMessage(0)

    def notify(s, hwnd, msg, wparam, lparam):
        
        if lparam == win32con.WM_LBUTTONDBLCLK:
            pass
        elif lparam == win32con.WM_RBUTTONUP:
            s.show_menu()
        elif lparam == win32con.WM_LBUTTONUP:
            nid = (s.hwnd, 0)
            win32gui.Shell_NotifyIcon(win32gui.NIM_DELETE, nid)
            win32gui.PostQuitMessage(0)
            if Main:
               Main.root.deiconify()
            #win32gui.UnregisterClass(s.classAtom,None)
        return True


    def _add_ids_to_menu_options(s, menu_options):
        result = []
        for menu_option in menu_options:
            option_text, option_icon, option_action = menu_option
            if callable(option_action) or option_action in s.SPECIAL_ACTIONS:
                s.menu_actions_by_id.add((s._next_action_id, option_action))
                result.append(menu_option + (s._next_action_id,))
            else:
                result.append((option_text,
                               option_icon,
                               s._add_ids_to_menu_options(option_action),
                               s._next_action_id))
            s._next_action_id += 1
        return result
        
    def refresh_icon(s, **data):
        hinst = win32gui.GetModuleHandle(None)
        if os.path.isfile(s.icon): 
            icon_flags = win32con.LR_LOADFROMFILE | win32con.LR_DEFAULTSIZE
            hicon = win32gui.LoadImage(hinst,
                                       s.icon,
                                       win32con.IMAGE_ICON,
                                       0,
                                       0,
                                       icon_flags)
        else:
            hicon = win32gui.LoadIcon(0, win32con.IDI_APPLICATION)

        if s.notify_id: message = win32gui.NIM_MODIFY
        else: message = win32gui.NIM_ADD
        s.notify_id = (s.hwnd,
                          0,
                          win32gui.NIF_ICON | win32gui.NIF_MESSAGE | win32gui.NIF_TIP,
                          win32con.WM_USER+20,
                          hicon,
                          s.hover_text)
        win32gui.Shell_NotifyIcon(message, s.notify_id)

    def create_menu(s, menu, menu_options):
        for option_text, option_icon, option_action, option_id in menu_options[::-1]:
            if option_icon:
                option_icon = s.prep_menu_icon(option_icon)
            
            if option_id in s.menu_actions_by_id:                
                item, extras = win32gui_struct.PackMENUITEMINFO(text=option_text,
                                                                hbmpItem=option_icon,
                                                                wID=option_id)
                win32gui.InsertMenuItem(menu, 0, 1, item)
            else:
                submenu = win32gui.CreatePopupMenu()
                s.create_menu(submenu, option_action)
                item, extras = win32gui_struct.PackMENUITEMINFO(text=option_text,
                                                                hbmpItem=option_icon,
                                                                hSubMenu=submenu)
                win32gui.InsertMenuItem(menu, 0, 1, item)

    def prep_menu_icon(s, icon):
        ico_x = win32api.GetSystemMetrics(win32con.SM_CXSMICON)
        ico_y = win32api.GetSystemMetrics(win32con.SM_CYSMICON)
        hicon = win32gui.LoadImage(0, icon, win32con.IMAGE_ICON, ico_x, ico_y, win32con.LR_LOADFROMFILE)

        hdcBitmap = win32gui.CreateCompatibleDC(0)
        hdcScreen = win32gui.GetDC(0)
        hbm = win32gui.CreateCompatibleBitmap(hdcScreen, ico_x, ico_y)
        hbmOld = win32gui.SelectObject(hdcBitmap, hbm)
        brush = win32gui.GetSysColorBrush(win32con.COLOR_MENU)
        win32gui.FillRect(hdcBitmap, (0, 0, 16, 16), brush)
        win32gui.DrawIconEx(hdcBitmap, 0, 0, hicon, ico_x, ico_y, 0, 0, win32con.DI_NORMAL)
        win32gui.SelectObject(hdcBitmap, hbmOld)
        win32gui.DeleteDC(hdcBitmap)
        
        return hbm
    def windowdestory(s):
        win32gui.DestroyWindow(s.hwnd)
    def command(s, hwnd, msg, wparam, lparam):
        id = win32gui.LOWORD(wparam)
        s.execute_menu_option(id)
        
    def execute_menu_option(s, id):
        menu_action = s.menu_actions_by_id[id]      
        if menu_action == s.QUIT:
            win32gui.DestroyWindow(s.hwnd)
        else:
            menu_action(s)
	

class _Main:
    def main(s):
        global wifistatus 
        s.root = Tk.Tk()
        s.root.title("Free WIFI Protector")
        s.root.iconbitmap("wifi.ico")
        icons='wifi.ico'
        hover_text = "SysTrayIcon.py Demo"
        menu_options = (("changeIcon", None, s.switch_icon),
        ("secondlist", None, (('changeIcon', None, s.switch_icon),)))
		
        ssidThread = Thread(target=s.catchssid, name="myThread") 
        ssidThread.setDaemon(True)    
        ssidThread.start()
        photo = Tk.PhotoImage(file='title.gif')
        lab=Tk.Label(image=photo,width=100,height = 100)
        lab.pack()
        lab2=Tk.Label(text="Free-WIFI Protector", font=("Arial", 24),width=30,height = 2)
        lab2.pack()
        
        s.v= StringVar()
       # Key= Tk.Label(s.root,width=100,height=5 ,textvariable=s.v,state='disabled')
        #Key.pack()
        #print wifi
        #WIFISSID= Tk.Label(s.root, text="SSID: "+wifi ,font=('Arial' , 20))
        #WIFISSID.pack()
        print wifi
        '''
        btn1 =Tk.Button(image=photoitaiwan,text="iTaiwan",width =100 , height =100)
        btn1.config(command = s.catch)
        btn1.place(relx=0.1,rely=0.5)
        #if wifi=='My':
        #   s.catch()
        #else:
        #   print 'fail'
        btn2 =Tk.Button( image=photostarbucks,text="starbucks",width =100 , height =100)
        btn2.place(relx=0.45,rely=0.5)
        btn3 =Tk.Button(image=photoyzu,text="yzu",width =100 , height =100)
        btn3.place(relx=0.8,rely=0.5) '''
        #bt4=Tk.Button(text="重新整理",width=10,height=2,command=s.reboot)
        #bt4.place(relx=0.45,rely=0.8)
        s.sysTrayIcon = SysTrayIcon(icons, hover_text, menu_options, on_quit = s.exit, default_menu_index = 1)
        s.root.bind("<Unmap>", lambda event: s.Unmap() if s.root.state() == 'iconic' else False)
        s.root.protocol('WM_DELETE_WINDOW', s.exit)
        s.root.resizable(0,0)
        s.root.geometry("700x400")
        s.root.mainloop()
    

    def catchssid(self):
      
       while True:
        b=-1
        c=0
        ssid=[]
        a=subprocess.check_output("netsh wlan show interfaces")
        for line in a.split():
            ssid.append(line)
            b=b+1
            if line.startswith("SSID"):
                c=b+2
            #print "SSID=",ssid[c]
        wifi=ssid[c]
        print wifi
        if wifi=="iTaiwan":
         print "sniffer"
         pcap = sniff(count=500)
         wrpcap('demo.pcap', pcap)#打包成wireshock檔
        #ss='30:82:01:0a:02:82:01:01:00:c1:ff:01:9a:11:39:d3:33:de:1c:0d:26:47:02:29:d6:65:2c:7d:de:60:72:44:91:26:b3:b9:4b:24:5e:d7:1b:08:4d:35:78:c7:ea:1a:09:44:20:ab:fb:63:62:21:87:4b:2e:be:ae:8e:16:7e:2b:7b:d9:2a:9f:b3:3e:d4:c1:e7:fe:80:c5:a1:3b:35:93:f9:83:f4:b0:32:66:2a:7e:37:23:40:bd:12:73:eb:a4:da:d0:c4:8f:85:c4:fa:50:0a:97:f3:ad:11:f2:94:ca:6f:b7:9e:95:fa:34:b2:db:b5:1e:63:78:2b:86:99:f7:51:66:14:eb:34:0c:4a:a6:32:16:7e:4f:5f:e5:e6:b8:84:3c:fa:97:cb:94:17:22:d3:64:bf:46:bb:3f:d8:5d:08:f2:39:03:b7:1a:de:56:91:dd:13:ea:f2:21:c8:fa:ca:83:37:64:2e:fc:ea:8d:1c:1c:6b:e2:80:6e:b3:f2:80:fe:67:ca:e2:f0:d9:09:75:49:87:9e:77:5d:ae:61:fd:e0:25:91:c4:01:08:f4:e3:f0:ef:f8:0f:ea:71:8f:27:b0:fd:dc:71:79:90:67:0e:81:1e:98:60:86:cc:e3:59:2b:f7:4a:0e:f9:bc:cc:44:a6:95:b4:c1:82:92:7a:95:98:34:e8:3f:4c:17:a7:02:03:01:00:01'
         ss="3082010a0282010100c1ff019a1139d333de1c0d26470229d6652c7dde6072449126b3b94b245ed71b084d3578c7ea1a094420abfb636221874b2ebeae8e167e2b7bd92a9fb33ed4c1e7fe80c5a13b3593f983f4b032662a7e372340bd1273eba4dad0c48f85c4fa500a97f3ad11f294ca6fb79e95fa34b2dbb51e63782b8699f7516614eb340c4aa632167e4f5fe5e6b8843cfa97cb941722d364bf46bb3fd85d08f23903b71ade5691dd13eaf221c8faca8337642efcea8d1c1c6be2806eb3f280fe67cae2f0d9097549879e775dae61fde02591c40108f4e3f0eff80fea718f27b0fddc717990670e811e986086cce3592bf74a0ef9bccc44a695b4c182927a959834e83f4c17a70203010001"
         s =hexlify(str(pcap[TLS][0]))
         for i in range(len(pcap[TLS])):
             s+=hexlify(str(pcap[TLS][i]))
         result = ss in s
         if result== 1 :
           #messagebox.showinfo(title='Fucking True wifi', message='真的wifi')
           checklab=Tk.Label(text="此wifi安全無虞", font=("Arial", 24),fg = "green", width=30,height = 2)
           checklab2=Tk.Label(text="敬請安心使用", font=("Arial", 24),fg = "green", width=30,height = 2)
           checklab.pack()
           checklab2.pack()
         else:
             #messagebox.showinfo(title='Fucking False wifi', message='假的wifi')
             checklab1=Tk.Label(text="此WIFI有安全疑慮", font=("Arial", 24),fg = "red", width=30,height = 2)
             checklab2=Tk.Label(text="請盡速斷線", font=("Arial", 24),fg = "red", width=30,height = 2)
             #checklab=Tk.Label(text="假的wifi", font=("Arial", 36),fg = "red", width=30,height = 2)
             checklab1.pack()
             checklab2.pack()
         break 
      
          #sprint "執行異常"
    def switch_icon(s, _sysTrayIcon, icons = 'wifi.ico'):
        _sysTrayIcon.icon = icons
        _sysTrayIcon.refresh_icon()

    def Unmap(s):
        s.root.withdraw()
        s.sysTrayIcon.show_icon()


    def exit(s, _sysTrayIcon = None):
        s.root.destroy()
        print ('exit...')
    '''
    def reboot(s):
        #s.root.withdraw()
         
        s.root.destroy()
        #s.catchssid()
        #s.sysTrayIcon.windowdestory()
        win32gui.UnregisterClass(s.sysTrayIcon.classAtom,None)
        #win32gui.PostMessage(s.sysTrayIcon.hwnd,win32con.WM_CLOSE,0,0)
       
        #wrong = tkinter.Toplevel()
        execfile('HideToTeskbar3.py')'''
    
if __name__ == '__main__':
    Main = _Main()
    Main.main()

